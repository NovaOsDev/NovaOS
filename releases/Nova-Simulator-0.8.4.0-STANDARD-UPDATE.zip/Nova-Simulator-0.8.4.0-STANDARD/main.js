const { app, BrowserWindow, ipcMain, dialog, shell } = require("electron");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const https = require("https");
const os = require("os");
const { spawn } = require("child_process");

const NOVA_VERSION = "0.8.4.0";
const UPDATE_MANIFEST = "https://raw.githubusercontent.com/NovaOsDev/NovaOS/main/update-standard.json";
let verifiedUpdate = null;

function versionParts(v){ return String(v).split(".").map(x=>parseInt(x,10)||0); }
function isNewer(a,b){ const A=versionParts(a),B=versionParts(b),n=Math.max(A.length,B.length); for(let i=0;i<n;i++){ if((A[i]||0)!==(B[i]||0)) return (A[i]||0)>(B[i]||0); } return false; }
function getJson(url){ return new Promise((resolve,reject)=>{ https.get(url,{headers:{"User-Agent":"NovaOS-Updater"}},res=>{ if(res.statusCode>=300&&res.statusCode<400&&res.headers.location) return resolve(getJson(new URL(res.headers.location,url).toString())); if(res.statusCode!==200){res.resume();return reject(new Error(`HTTP ${res.statusCode}`));} let d="";res.on("data",c=>d+=c);res.on("end",()=>{try{resolve(JSON.parse(d))}catch(e){reject(e)}}); }).on("error",reject); }); }
function download(url,dest,onProgress){ return new Promise((resolve,reject)=>{ const go=u=>https.get(u,{headers:{"User-Agent":"NovaOS-Updater"}},res=>{ if(res.statusCode>=300&&res.statusCode<400&&res.headers.location){res.resume();return go(new URL(res.headers.location,u).toString());} if(res.statusCode!==200){res.resume();return reject(new Error(`HTTP ${res.statusCode}`));} const total=Number(res.headers["content-length"]||0); let received=0; const f=fs.createWriteStream(dest); res.on("data",chunk=>{received+=chunk.length; if(total>0 && onProgress) onProgress(Math.max(1,Math.min(99,Math.round(received/total*100))));}); res.pipe(f); f.on("finish",()=>f.close(()=>{if(onProgress)onProgress(100);resolve();})); f.on("error",reject); }).on("error",reject); go(url); }); }
function sha256(file){ return new Promise((resolve,reject)=>{const h=crypto.createHash("sha256"),r=fs.createReadStream(file);r.on("data",d=>h.update(d));r.on("end",()=>resolve(h.digest("hex")));r.on("error",reject);}); }

function createWindow() {
  const win = new BrowserWindow({
    width: 1280, height: 800, minWidth: 900, minHeight: 600,
    backgroundColor: "#05090d", autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, nodeIntegration: false, webviewTag: true }
  });
  win.loadFile("index.html");
}

ipcMain.handle("nova:pickGame", async () => {
  const r = await dialog.showOpenDialog({ title: "Spiel auswählen", properties: ["openFile"], filters: process.platform === "win32" ? [{name:"Programme",extensions:["exe","bat","cmd"]},{name:"Alle Dateien",extensions:["*"]}] : [{name:"Alle Dateien",extensions:["*"]}] });
  if (r.canceled || !r.filePaths[0]) return null;
  const filePath=r.filePaths[0];
  return { path:filePath, name:path.basename(filePath,path.extname(filePath)) };
});
ipcMain.handle("nova:launchGame", async (_e, filePath) => {
  if (!filePath || typeof filePath !== "string") return {ok:false,error:"Ungültiger Pfad"};
  const err=await shell.openPath(filePath);
  return err ? {ok:false,error:err} : {ok:true};
});

ipcMain.handle("nova:checkForUpdates", async () => {
  try {
    const m=await getJson(UPDATE_MANIFEST);
    if(m.edition!=="STANDARD" || !m.version || !m.url || !m.sha256) throw new Error("Ungültiges Update-Manifest");
    verifiedUpdate=m;
    return {ok:true,current:NOVA_VERSION,available:isNewer(m.version,NOVA_VERSION),version:m.version,notes:m.notes||"",published:m.published||""};
  } catch(e){ verifiedUpdate=null; return {ok:false,error:e.message,current:NOVA_VERSION}; }
});

ipcMain.handle("nova:downloadUpdate", async (event) => {
  let dest = null;
  try {
    if(!verifiedUpdate || !isNewer(verifiedUpdate.version,NOVA_VERSION)) return {ok:false,error:"Kein geprüftes Update verfügbar."};

    const tempRoot=path.join(app.getPath("temp"),"NovaOS-Update");
    fs.mkdirSync(tempRoot,{recursive:true});
    dest=path.join(tempRoot,`Nova-Simulator-${verifiedUpdate.version}-STANDARD.zip`);
    try{fs.unlinkSync(dest)}catch{}

    event.sender.send("nova:updateProgress",{phase:"download",percent:0,text:"Download wird vorbereitet…"});
    await download(verifiedUpdate.url,dest,p=>event.sender.send("nova:updateProgress",{phase:"download",percent:p,text:`Update wird heruntergeladen… ${p}%`}));

    event.sender.send("nova:updateProgress",{phase:"verify",percent:100,text:"Download abgeschlossen · Datei wird geprüft…"});
    const actual=await sha256(dest);
    if(actual.toLowerCase()!==String(verifiedUpdate.sha256).toLowerCase()){
      try{fs.unlinkSync(dest)}catch{}
      return {ok:false,error:"SHA-256-Prüfung fehlgeschlagen. Datei wurde gelöscht."};
    }

    event.sender.send("nova:updateProgress",{phase:"verify",percent:100,text:"SHA-256 geprüft · Installation wird vorbereitet…"});

    const runner=path.join(tempRoot,`runner-${Date.now()}`);
    try{fs.rmSync(runner,{recursive:true,force:true})}catch{}
    fs.cpSync(path.join(__dirname,"updater"),runner,{recursive:true});

    const plan={
      zip:dest,
      target:__dirname,
      launcher:path.join(__dirname,"START-NOVA.bat"),
      version:verifiedUpdate.version,
      runner
    };
    const planPath=path.join(tempRoot,`plan-${Date.now()}.json`);
    fs.writeFileSync(planPath,JSON.stringify(plan,null,2),"utf8");

    const child=spawn(process.execPath,[runner,planPath],{
      detached:true,
      stdio:"ignore",
      windowsHide:false
    });
    child.unref();

    setTimeout(()=>app.quit(),900);
    return {ok:true,installing:true,version:verifiedUpdate.version};
  } catch(e){
    return {ok:false,error:e.message};
  }
});

ipcMain.handle('nova:openUrl',async (_event,url)=>{try{const u=new URL(url);if(u.protocol!=='https:')return {ok:false};await shell.openExternal(u.toString());return {ok:true}}catch{return {ok:false}}});
app.whenReady().then(() => { createWindow(); app.on("activate",()=>{if(BrowserWindow.getAllWindows().length===0)createWindow()}); });
app.on("window-all-closed",()=>{if(process.platform!=="darwin")app.quit()});
