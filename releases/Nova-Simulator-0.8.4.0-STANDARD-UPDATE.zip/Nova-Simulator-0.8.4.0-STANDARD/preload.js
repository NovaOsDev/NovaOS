const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("nova", {
  version: "0.8.4.0",
  pickGame: () => ipcRenderer.invoke("nova:pickGame"),
  checkForUpdates: () => ipcRenderer.invoke("nova:checkForUpdates"),
  downloadUpdate: () => ipcRenderer.invoke("nova:downloadUpdate"),
  onUpdateProgress: (callback) => {
    const handler = (_event, data) => callback(data);
    ipcRenderer.on("nova:updateProgress", handler);
    return () => ipcRenderer.removeListener("nova:updateProgress", handler);
  },
  openUrl: (url)=>ipcRenderer.invoke("nova:openUrl",url),
  launchGame: (filePath) => ipcRenderer.invoke("nova:launchGame", filePath)
});
