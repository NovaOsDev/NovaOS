const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const boot=$("#boot"),setup=$("#setup"),lock=$("#lock"),desktop=$("#desktop");
let z=100, profile=null;

// 0.8.4.0 Hotfix: settings navigation is handled centrally in capture phase.
// This makes the sidebar reliable even when another window/drag handler consumes a click.
document.addEventListener("click", (e) => {
  const btn = e.target.closest("#settingsNav [data-settings-page]");
  if (!btn) return;
  e.preventDefault();
  e.stopPropagation();
  const page = btn.dataset.settingsPage;
  document.querySelectorAll("#settingsNav [data-settings-page]").forEach(x =>
    x.classList.toggle("active", x === btn)
  );
  document.querySelectorAll("#settings .settingsPage").forEach(x =>
    x.classList.toggle("active", x.dataset.page === page)
  );
}, true);

const NOVA_VERSION="0.8.4.0";
const NOVA_BUILD_ID="NOVA-0840-STD";
const NOVA_OWNER_BUILD=false;
const NOVA_DEVICE_NAME="Samuel";
const NOVA_APPS={browser:{id:"browser",name:"Nova Browser",icon:"◎",keywords:["browser","web","google"]},files:{id:"files",name:"Dateien",icon:"▰",keywords:["dateien","files","explorer"]},monitor:{id:"monitor",name:"System Monitor",icon:"◫",keywords:["monitor","system","leistung"]},settings:{id:"settings",name:"Einstellungen",icon:"⚙",keywords:["settings","einstellungen","personalisierung","update"]},terminal:{id:"terminal",name:"Terminal",icon:">_",keywords:["terminal","konsole","cmd"]},gaming:{id:"gaming",name:"Gaming Hub",icon:"🎮",keywords:["gaming","spiele","hub"]},store:{id:"store",name:"Nova Store",icon:"◇",keywords:["store","shop","apps"]},notes:{id:"notes",name:"Nova Notes",icon:"✎",keywords:["notes","notizen","text"],store:true},clockapp:{id:"clockapp",name:"Nova Clock",icon:"◷",keywords:["clock","uhr","zeit"],store:true},tasks:{id:"tasks",name:"Nova Tasks",icon:"✓",keywords:["tasks","aufgaben","todo"],store:true},calculator:{id:"calculator",name:"Nova Calculator",icon:"＋",keywords:["calculator","rechner","mathe"],store:true},focus:{id:"focus",name:"Nova Focus",icon:"◉",keywords:["focus","timer","konzentration"],store:true}};
function applyRole(){
  const isOwner=NOVA_OWNER_BUILD;
  $$(".ownerOnly").forEach(x=>x.classList.toggle("hidden",!isOwner));
  const rt=$("#roleText"),rp=$("#rolePill");
  if(rt)rt.textContent=isOwner?"NOVA OWNER PC · Samuel":"Standard Nova PC";
  if(rp){rp.textContent=isOwner?"OWNER":"USER";rp.style.color=isOwner?"var(--cyan)":"";}
  return isOwner;
}
const saved=()=>{try{return JSON.parse(localStorage.getItem("novaProfile"))}catch{return null}};
const save=p=>localStorage.setItem("novaProfile",JSON.stringify(p));

setTimeout(()=>{boot.classList.add("hidden");profile=saved(); if(profile) showLock(); else setup.classList.remove("hidden")},1700);

function showLock(){setup.classList.add("hidden");desktop.classList.add("hidden");lock.classList.remove("hidden");profile=saved()||profile;$("#loginName").textContent=profile?.name||"Nova User";$("#loginPass").value="";$("#loginMsg").textContent="";setTimeout(()=>$("#loginPass").focus(),50)}
function showDesktop(){lock.classList.add("hidden");desktop.classList.remove("hidden");$("#startName").textContent=profile.name;$("#profileText").textContent=profile.name+" · Lokales Simulator-Profil";applyRole();applyWallpaper(localStorage.getItem("novaWallpaper")||"aurora");toast("Willkommen zurück, "+profile.name+".")}
$("#setupNext").onclick=()=>{let n=$("#setupName").value.trim(),p=$("#setupPass").value,p2=$("#setupPass2").value;if(!n)return $("#setupMsg").textContent="Bitte gib einen Namen ein.";if(p.length<4)return $("#setupMsg").textContent="Nimm mindestens 4 Zeichen.";if(p!==p2)return $("#setupMsg").textContent="Die Passwörter stimmen nicht überein.";profile={name:n,password:p};save(profile);setup.classList.add("hidden");showDesktop()};
function login(){profile=saved();if(!profile)return showLock();if($("#loginPass").value===profile.password)showDesktop();else $("#loginMsg").textContent="Falsches Passwort."}
$("#loginBtn").onclick=login;$("#loginPass").addEventListener("keydown",e=>e.key==="Enter"&&login());

function openApp(id){if(id==="owner"&&!applyRole()){toast("Owner-Berechtigung erforderlich.");return;}if(NOVA_APPS[id]?.store&&!isStoreInstalled(id)){toast("Diese App ist nicht installiert.");id="store";}let w=$("#"+id);if(!w)return;w.classList.remove("hidden");w.style.zIndex=++z;$("#start").classList.add("hidden");addTask(id);if(id==="shortcuts")renderShortcuts();if(id==="terminal")setTimeout(()=>$("#termIn").focus(),30);if(id==="store")renderStore();if(id==="tasks")renderTasks();}
function addTask(id){
  if(document.querySelector(`[data-task="${id}"]`))return;
  const meta=NOVA_APPS[id]||{name:id,icon:"•"};
  let b=document.createElement("button");
  b.className="taskapp";
  b.dataset.task=id;
  b.innerHTML=`<span class="taskappIcon">${meta.icon}</span><span class="taskappText">${meta.name}</span>`;
  b.onclick=()=>{let w=$("#"+id);w.classList.toggle("hidden");if(!w.classList.contains("hidden"))w.style.zIndex=++z};
  $("#running").appendChild(b)
}
function removeTask(id){document.querySelector(`[data-task="${id}"]`)?.remove()}
$$("[data-open]").forEach(b=>b.ondblclick=()=>openApp(b.dataset.open));
$$("#start [data-open]").forEach(b=>b.onclick=()=>openApp(b.dataset.open));

$$(".window").forEach(w=>{let drag=false,ox=0,oy=0,restore=null;w.onmousedown=()=>w.style.zIndex=++z;let bar=w.querySelector(".titlebar");bar.addEventListener("mousedown",e=>{if(e.target.tagName==="BUTTON")return;drag=true;ox=e.clientX-w.offsetLeft;oy=e.clientY-w.offsetTop});document.addEventListener("mousemove",e=>{if(!drag)return;w.style.left=Math.max(0,Math.min(innerWidth-w.offsetWidth,e.clientX-ox))+"px";w.style.top=Math.max(2,Math.min(innerHeight-50-w.offsetHeight,e.clientY-oy))+"px"});document.addEventListener("mouseup",()=>drag=false);
 w.querySelector("[data-close]").onclick=()=>{w.classList.add("hidden");removeTask(w.id)};
 w.querySelector("[data-min]").onclick=()=>w.classList.add("hidden");
 w.querySelector("[data-max]").onclick=()=>{if(!w.dataset.max){restore={left:w.style.left,top:w.style.top,width:w.style.width,height:w.style.height};Object.assign(w.style,{left:"0",top:"2px",width:"100%",height:"calc(100% - 52px)"});w.dataset.max=1}else{Object.assign(w.style,restore);delete w.dataset.max}}});

$("#startBtn").onclick=e=>{$("#start").classList.toggle("hidden");$("#quick").classList.add("hidden");e.stopPropagation()};
function toggleQuick(e){$("#quick").classList.toggle("hidden");$("#start").classList.add("hidden");if(e)e.stopPropagation()}
$("#quickBtn").onclick=toggleQuick;
$("#clockBtn").onclick=toggleQuick;
desktop.addEventListener("mousedown",e=>{if(!e.target.closest("#start")&&!e.target.closest("#startBtn"))$("#start").classList.add("hidden");if(!e.target.closest("#quick")&&!e.target.closest("#quickBtn"))$("#quick").classList.add("hidden");if(!e.target.closest("#taskSearchPanel")&&!e.target.closest("#taskSearch"))$("#taskSearchPanel")?.classList.add("hidden")});
$("#power").onclick=showLock;$("#lockNow").onclick=showLock;
$("#resetProfile").onclick=()=>{if(confirm("Nova-Profil wirklich zurücksetzen?")){localStorage.removeItem("novaProfile");location.reload()}};
$("#gridToggle").onclick=()=>desktop.classList.toggle("no-grid");

const web=$("#web"),url=$("#url");function norm(v){v=v.trim();if(!v)return"https://www.google.com";if(/^https?:\/\//i.test(v))return v;if(v.includes(".")&&!v.includes(" "))return"https://"+v;return"https://www.google.com/search?q="+encodeURIComponent(v)}
function go(){web.src=norm(url.value)}$("#go").onclick=go;url.onkeydown=e=>e.key==="Enter"&&go();$("#back").onclick=()=>web.canGoBack()&&web.goBack();$("#forward").onclick=()=>web.canGoForward()&&web.goForward();$("#reload").onclick=()=>web.reload();web.addEventListener("did-navigate",e=>url.value=e.url);web.addEventListener("did-navigate-in-page",e=>url.value=e.url);

$("#termIn").addEventListener("keydown",e=>{if(e.key!=="Enter")return;let v=e.target.value.trim(),out=$("#termOut");out.innerHTML+=`nova&gt; ${escapeHtml(v)}<br>`;let a=v.toLowerCase();if(a==="help")out.innerHTML+="help, clear, version, whoami, date, echo [text], open browser/files/settings<br>";else if(a==="clear")out.innerHTML="";else if(a==="version")out.innerHTML+="Nova Simulator 0.8.4.0<br>";else if(a==="whoami")out.innerHTML+=escapeHtml(profile?.name||"unknown")+"<br>";else if(a==="date")out.innerHTML+=new Date().toLocaleString("de-DE")+"<br>";else if(a.startsWith("echo "))out.innerHTML+=escapeHtml(v.slice(5))+"<br>";else if(a.startsWith("open ")){let id=a.slice(5);if(["browser","files","settings"].includes(id))openApp(id);else out.innerHTML+="App nicht gefunden.<br>"}else if(a && runShortcutByName(a))out.innerHTML+="Shortcut gestartet.<br>";else if(a)out.innerHTML+="Unbekannter Befehl. Tippe help.<br>";e.target.value="";out.parentElement.scrollTop=out.parentElement.scrollHeight});
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function toast(t){let x=$("#toast");x.querySelector("span").textContent=t;x.classList.remove("hidden");clearTimeout(window.toastT);window.toastT=setTimeout(()=>x.classList.add("hidden"),2800)}
// Nova 0.6.3 Game Mode — limits simulator-side visual/background activity only.
let gameMode=false, fpsFrames=0, fpsLast=performance.now();
function setGameMode(on){
  gameMode=!!on; document.body.classList.toggle('game-mode',gameMode);
  const labels=[document.querySelector('#gameModeBig span'),document.querySelector('#quickGameMode')];
  if(labels[0]) labels[0].textContent=gameMode?'AN':'AUS';
  if(labels[1]) { labels[1].textContent='🎮 Game Mode: '+(gameMode?'AN':'AUS'); labels[1].classList.toggle('active',gameMode); }
  const pm=document.querySelector('#perfMode'); if(pm)pm.textContent=gameMode?'ON':'OFF';
  toast(gameMode?'Game Mode aktiviert — Nova reduziert Hintergrundaktivität.':'Game Mode deaktiviert.');
}
function updatePerf(){
  const cpu=navigator.hardwareConcurrency||'--';
  const ram=(performance.memory && performance.memory.usedJSHeapSize)?Math.round(performance.memory.usedJSHeapSize/1048576)+' MB':'nicht verfügbar';
  const fps=Math.round(fpsFrames*1000/Math.max(1,performance.now()-fpsLast));
  const a=document.querySelector('#perfCpu'),b=document.querySelector('#perfRam'),f=document.querySelector('#perfFps');
  if(a)a.textContent=cpu; if(b)b.textContent=ram; if(f)f.textContent=Math.min(240,Math.max(0,fps));
  fpsFrames=0;fpsLast=performance.now();
}
let fpsLoopRunning=false;
function fpsLoop(){if(!fpsLoopRunning)return;fpsFrames++;requestAnimationFrame(fpsLoop)}
function startPerfMeter(){if(fpsLoopRunning)return;fpsLoopRunning=true;fpsFrames=0;fpsLast=performance.now();requestAnimationFrame(fpsLoop)}
setInterval(()=>{if(!document.querySelector('#gaming')?.classList.contains('hidden'))updatePerf()},1500);
function tick(){let d=new Date();$("#clock").textContent=d.toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"});$("#date").textContent=d.toLocaleDateString("de-DE",{day:"2-digit",month:"2-digit",year:"numeric"});$("#lockClock").textContent=d.toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"});$("#lockDate").textContent=d.toLocaleDateString("de-DE",{weekday:"long",day:"numeric",month:"long"})}tick();setInterval(tick,1000);

$("#devMode")?.addEventListener("click",()=>{
  if(!applyRole())return;
  const b=$("#devMode"),on=b.dataset.on!=="1";b.dataset.on=on?"1":"0";b.querySelector("span").textContent=on?"ON":"OFF";
  ownerLog(`Developer Mode ${on?"enabled":"disabled"}`);
});
$("#systemInfo")?.addEventListener("click",()=>{
  if(!applyRole())return;
  $("#ownerLog").innerHTML+=`Build: Nova Simulator 0.8.4.0 | Build ID: NOVA-0840-STD | Runtime: Electron | Role: OWNER PC<br>`;
});
$("#ownerLock")?.addEventListener("click",()=>{if(applyRole()){ownerLog("Nova wurde gesperrt");showLock()}});
$("#ownerToast")?.addEventListener("click",()=>{if(applyRole()){ownerLog("Test-Benachrichtigung gesendet");toast("Owner Service: Test erfolgreich.")}});



// Owner Control Center 0.8.4.0 — lightweight diagnostics only while Nova is open.
const novaSessionStart=Date.now();
function ownerLog(message){const log=$("#ownerLog");if(!log)return;const t=new Date().toLocaleTimeString("de-DE");log.innerHTML+=`[${t}] ${escapeHtml(message)}<br>`;log.scrollTop=log.scrollHeight;}
function updateOwnerDashboard(){
  if(!NOVA_OWNER_BUILD)return;
  const sec=Math.floor((Date.now()-novaSessionStart)/1000), hh=String(Math.floor(sec/3600)).padStart(2,'0'), mm=String(Math.floor(sec%3600/60)).padStart(2,'0'), ss=String(sec%60).padStart(2,'0');
  const mem=(performance.memory&&performance.memory.usedJSHeapSize)?Math.round(performance.memory.usedJSHeapSize/1048576)+' MB':'n/a';
  if($("#ownerUptime"))$("#ownerUptime").textContent=`${hh}:${mm}:${ss}`;
  if($("#ownerMemory"))$("#ownerMemory").textContent=mem;
  if($("#ownerThreads"))$("#ownerThreads").textContent=navigator.hardwareConcurrency||'--';
  if($("#ownerGame"))$("#ownerGame").textContent=gameMode?'AN':'AUS';
  if($("#ownerFocus"))$("#ownerFocus").textContent=focusMode?'AN':'AUS';
  const lp=$("#powerProfile"); if($("#ownerProfile"))$("#ownerProfile").textContent=lp?lp.value:'Ausgeglichen';
}
setInterval(()=>{if(!$("#owner")?.classList.contains("hidden"))updateOwnerDashboard()},1000);
$("#clearOwnerLog")?.addEventListener("click",()=>{$("#ownerLog").innerHTML="NOVA DIAGNOSTIC LOG CLEARED<br>"});

// Nova Files 0.6 — virtual local file system stored in localStorage.
const FS_KEY="novaFS06";
const defaultFS=()=>({type:"folder",children:{
  "Home":{type:"folder",children:{
    "Dokumente":{type:"folder",children:{"Willkommen.txt":{type:"text",content:"Willkommen bei Nova Files 0.6!\n\nDateien und Ordner sind jetzt anklickbar."}}},
    "Downloads":{type:"folder",children:{}},"Bilder":{type:"folder",children:{}},
    "Lies mich.txt":{type:"text",content:"Nova Simulator 0.8.4.0\nCreated by Samuel.Vieaira.Rodrigues"}
  }},"Nova Drive":{type:"folder",children:{"System Info.txt":{type:"text",content:"Nova Drive\nBuild 0.8.4.0"}}}
}});
let novaFS; try{novaFS=JSON.parse(localStorage.getItem(FS_KEY))||defaultFS()}catch{novaFS=defaultFS()}
let filePath=["Home"], fileHistory=[], selectedFile=null;
const saveFS=()=>localStorage.setItem(FS_KEY,JSON.stringify(novaFS));
function nodeAt(path=filePath){let n=novaFS;for(const p of path){if(!n.children?.[p])return null;n=n.children[p]}return n}
function renderFiles(){const n=nodeAt();if(!n||n.type!=="folder"){filePath=["Home"];return renderFiles()}selectedFile=null;$("#filePath").textContent="Nova / "+filePath.join(" / ");$("#fileTitle").textContent=filePath.at(-1)||"Nova";const g=$("#fileGrid");g.innerHTML="";const entries=Object.entries(n.children||{});$("#fileCount").textContent=entries.length+" Elemente";entries.sort((a,b)=>(a[1].type===b[1].type?a[0].localeCompare(b[0]):a[1].type==="folder"?-1:1)).forEach(([name,item])=>{let d=document.createElement("button");d.className="fileitem";d.dataset.name=name;d.innerHTML=`<span>${item.type==="folder"?"📁":"📄"}</span><b>${escapeHtml(name)}</b><small>${item.type==="folder"?"Ordner":"Textdatei"}</small>`;d.onclick=()=>{if(item.type==="folder"){fileHistory.push([...filePath]);filePath.push(name);renderFiles()}else{selectedFile=name;openTextFile(name,item)}};g.appendChild(d)});$$('.place').forEach(b=>b.classList.toggle('active',b.dataset.path===filePath.join('/')))}
function openTextFile(name,item){const changed=prompt(name+"\n\nText bearbeiten:",item.content??"");if(changed!==null){item.content=changed;saveFS();toast(name+" gespeichert.")}}
$("#fileBack").onclick=()=>{if(fileHistory.length){filePath=fileHistory.pop();renderFiles()}};
$("#fileUp").onclick=()=>{if(filePath.length>1){fileHistory.push([...filePath]);filePath.pop();renderFiles()}};
$("#fileHome").onclick=()=>{fileHistory.push([...filePath]);filePath=["Home"];renderFiles()};
$$('.place').forEach(b=>b.onclick=()=>{fileHistory.push([...filePath]);filePath=b.dataset.path.split('/');renderFiles()});
$("#newFolder").onclick=()=>{let name=prompt("Name des neuen Ordners:","Neuer Ordner");if(!name)return;let n=nodeAt();if(n.children[name])return toast("Dieser Name existiert bereits.");n.children[name]={type:"folder",children:{}};saveFS();renderFiles()};
$("#newText").onclick=()=>{let name=prompt("Name der Textdatei:","Neue Datei.txt");if(!name)return;if(!name.toLowerCase().endsWith('.txt'))name+='.txt';let n=nodeAt();if(n.children[name])return toast("Dieser Name existiert bereits.");n.children[name]={type:"text",content:""};saveFS();renderFiles()};
$("#deleteFile").onclick=()=>{if(!selectedFile)return toast("Wähle zuerst eine Datei oder einen Ordner.");if(confirm('"'+selectedFile+'" wirklich löschen?')){delete nodeAt().children[selectedFile];saveFS();renderFiles()}};
$("#renameFile").onclick=()=>{if(!selectedFile)return toast("Wähle zuerst ein Element.");let nn=prompt("Neuer Name:",selectedFile);if(!nn||nn===selectedFile)return;let n=nodeAt();if(n.children[nn])return toast("Dieser Name existiert bereits.");n.children[nn]=n.children[selectedFile];delete n.children[selectedFile];saveFS();renderFiles()};
const oldOpenApp=openApp;openApp=function(id){oldOpenApp(id);if(id==='files')renderFiles();if(id==='gaming'){startPerfMeter();updatePerf();renderGameLibrary();}};

// Nova 0.6.3 personalization
const accents={cyan:'#48cfe3',violet:'#a78bfa',green:'#58d68d',amber:'#f2b84b'};
function setAccent(name){const c=accents[name]||accents.cyan;document.documentElement.style.setProperty('--cyan',c);document.documentElement.style.setProperty('--accent-soft',c+'22');localStorage.setItem('novaAccent',name);$$('[data-accent]').forEach(b=>b.classList.toggle('chosen',b.dataset.accent===name));}
function applyWallpaper(name){const wp=name||'aurora';desktop.dataset.wallpaper=wp;localStorage.setItem('novaWallpaper',wp);$$('[data-wallpaper]').forEach(b=>b.classList.toggle('chosen',b.dataset.wallpaper===wp));}
$$('[data-accent]').forEach(b=>b.onclick=()=>setAccent(b.dataset.accent));
$$('[data-wallpaper]').forEach(b=>b.onclick=()=>{applyWallpaper(b.dataset.wallpaper);toast('Wallpaper geändert: '+b.textContent)});
setAccent(localStorage.getItem('novaAccent')||'cyan');
applyWallpaper(localStorage.getItem('novaWallpaper')||'aurora');


// Nova Gaming Hub 0.6.3 — intentionally isolated from boot logic.
const GAME_LIBRARY_KEY='novaGameLibrary063';
let selectedGameIndex=-1, focusMode=false;
function getGameLibrary(){try{return JSON.parse(localStorage.getItem(GAME_LIBRARY_KEY))||[]}catch{return []}}
function saveGameLibrary(v){localStorage.setItem(GAME_LIBRARY_KEY,JSON.stringify(v))}
function renderGameLibrary(){
  const host=document.querySelector('#gameLibrary'); if(!host)return; const games=getGameLibrary(); host.innerHTML='';
  if(!games.length){host.innerHTML='<div class="emptyGames">Noch keine Spiele hinzugefügt.<br><small>Klicke unten auf „Eigenes Spiel hinzufügen“.</small></div>';return}
  games.forEach((g,i)=>{const b=document.createElement('button');b.className='gamecard'+(i===selectedGameIndex?' selected':'');b.innerHTML='<strong>🎮 '+escapeHtml(g.name)+'</strong><small>Doppelklick zum Starten</small>';b.onclick=()=>{selectedGameIndex=i;renderGameLibrary()};b.ondblclick=()=>launchGame(i);host.appendChild(b)});
}
async function launchGame(i){const games=getGameLibrary(),g=games[i];if(!g)return;if(gameMode===false)setGameMode(true);const res=await window.nova?.launchGame?.(g.path);if(res?.ok)toast(g.name+' wird gestartet.');else toast('Start fehlgeschlagen: '+(res?.error||'Unbekannter Fehler'))}
document.querySelector('#addGame')?.addEventListener('click',async()=>{const picked=await window.nova?.pickGame?.();if(!picked)return;const games=getGameLibrary();if(games.some(g=>g.path===picked.path))return toast('Dieses Spiel ist bereits in deiner Bibliothek.');games.push(picked);saveGameLibrary(games);selectedGameIndex=games.length-1;renderGameLibrary();toast(picked.name+' hinzugefügt.')});
document.querySelector('#removeGame')?.addEventListener('click',()=>{const games=getGameLibrary();if(selectedGameIndex<0||!games[selectedGameIndex])return toast('Wähle zuerst ein Spiel.');const n=games[selectedGameIndex].name;games.splice(selectedGameIndex,1);saveGameLibrary(games);selectedGameIndex=-1;renderGameLibrary();toast(n+' entfernt.')});
document.querySelector('#gameModeBig')?.addEventListener('click',()=>{setGameMode(!gameMode);document.querySelector('#gameModeBig')?.classList.toggle('active',gameMode)});
document.querySelector('#quickGameMode')?.addEventListener('click',()=>{setGameMode(!gameMode);document.querySelector('#gameModeBig')?.classList.toggle('active',gameMode)});
document.querySelector('#quickFocus')?.addEventListener('click',e=>{focusMode=!focusMode;e.currentTarget.textContent='☾ Fokus: '+(focusMode?'AN':'AUS');e.currentTarget.classList.toggle('on',focusMode);document.body.classList.toggle('focus-mode',focusMode);toast(focusMode?'Fokusmodus aktiviert — Hinweise werden reduziert.':'Fokusmodus deaktiviert.');ownerLog('Fokusmodus '+(focusMode?'aktiviert':'deaktiviert'));updateOwnerDashboard();});
document.querySelector('#gameFocus')?.addEventListener('click',()=>{focusMode=!focusMode;const b=document.querySelector('#gameFocus'),s=document.querySelector('#focusStatus');b.textContent=focusMode?'Fokus deaktivieren':'Fokus aktivieren';s.textContent=focusMode?'Fokus ist aktiv. Nova hält Hinweise möglichst ruhig.':'Fokus ist aus. Benachrichtigungen bleiben normal.';document.body.classList.toggle('focus-mode',focusMode);toast('Fokus '+(focusMode?'aktiviert.':'deaktiviert.'))});
document.querySelector('#perfProfile')?.addEventListener('change',e=>{const v=e.target.value;document.body.dataset.perf=v;localStorage.setItem('novaPerfProfile',v);toast('Nova-Profil: '+({balanced:'Ausgeglichen',performance:'Performance',eco:'Leicht'}[v]))});
const savedPerf=localStorage.getItem('novaPerfProfile')||'balanced';if(document.querySelector('#perfProfile'))document.querySelector('#perfProfile').value=savedPerf;document.body.dataset.perf=savedPerf;

// Sync Owner dashboard with quick settings without changing Windows settings.


// Owner RGB Mode 0.8.4.0 — visual Easter egg only; no extra background service.
const OWNER_RGB_KEY='novaOwnerRgb';
function setOwnerRgb(on, announce=true){
  if(!NOVA_OWNER_BUILD)return;
  document.body.classList.toggle('owner-rgb',!!on);
  const b=document.querySelector('#ownerRgb');
  if(b){b.dataset.on=on?'1':'0'; const sp=b.querySelector('span'); if(sp)sp.textContent=on?'ON':'OFF';}
  localStorage.setItem(OWNER_RGB_KEY,on?'1':'0');
  if(announce){ownerLog('RGB Mode '+(on?'aktiviert':'deaktiviert'));toast(on?'Owner RGB Mode aktiviert 🌈':'Owner RGB Mode deaktiviert.');}
}
document.querySelector('#ownerRgb')?.addEventListener('click',()=>setOwnerRgb(!document.body.classList.contains('owner-rgb')));
if(NOVA_OWNER_BUILD && localStorage.getItem(OWNER_RGB_KEY)==='1')setOwnerRgb(true,false);


// Owner-only RGB + Meme Chaos (0.8.4.0)
(() => {
  let chaosTimer = null, shuffleTimer = null, lastAudio = -1;
  const memeSources = [
    './assets/memes/meme1.mp4','./assets/memes/meme2.mp4','./assets/memes/meme3.mp4',
    './assets/memes/meme4.mp4','./assets/memes/meme5.mp4','./assets/memes/meme6.mp4'
  ];
  const findRgbButton = () => [...document.querySelectorAll('button')].find(b => /rgb/i.test((b.textContent || '')));
  const layer = () => document.querySelector('#memeChaosLayer');
  const audio = () => document.querySelector('#memeChaosAudio');

  function randomizeBoxes(){
    const L=layer(); if(!L) return;
    [...L.children].forEach((box,i)=>{
      // 0.8.4.0: keep every meme fully inside the usable area.
      const w = 15 + Math.random()*11;
      const maxLeft = Math.max(1, 98 - w);
      box.style.width = w+'vw';
      box.style.left = (1 + Math.random()*(maxLeft-1))+'vw';
      // 16:9 box height is ~0.5625*w vw; reserve top bar + taskbar.
      const hVh = (w * 0.5625) * (window.innerWidth / Math.max(1, window.innerHeight));
      const maxTop = Math.max(3, 92 - hVh);
      box.style.top = (2 + Math.random()*(maxTop-2))+'vh';
      box.style.zIndex = String(8801 + Math.floor(Math.random()*20));
    });
  }
  function buildMemeWall(){
    const L=layer(); if(!L || L.children.length) return;
    memeSources.forEach((src,i)=>{
      const box=document.createElement('div'); box.className='meme-chaos-box'; box.dataset.i=i;
      const v=document.createElement('video'); v.src=src; v.muted=true; v.loop=true; v.autoplay=true; v.playsInline=true; v.preload='auto';
      box.appendChild(v); L.appendChild(box); v.play().catch(()=>{});
    });
    randomizeBoxes();
  }
  function chooseNextAudio(){
    if(!document.body.classList.contains('rgb-chaos')) return;
    let n; do{ n=Math.floor(Math.random()*memeSources.length); }while(memeSources.length>1 && n===lastAudio);
    lastAudio=n;
    document.querySelectorAll('.meme-chaos-box').forEach((b,i)=>b.classList.toggle('sound-source',i===n));
    const a=audio(); if(!a)return; a.src=memeSources[n]; a.currentTime=0; a.volume=.75; a.play().catch(()=>{});
  }
  function startMemes(){
    const L=layer(); if(!L)return; buildMemeWall(); L.classList.remove('hidden');
    L.querySelectorAll('video').forEach(v=>v.play().catch(()=>{}));
    randomizeBoxes(); clearInterval(shuffleTimer); shuffleTimer=setInterval(randomizeBoxes,2200);
    chooseNextAudio();
  }
  function stopMemes(){
    clearInterval(shuffleTimer); shuffleTimer=null;
    const L=layer(); if(L){L.classList.add('hidden');L.querySelectorAll('video').forEach(v=>v.pause());}
    const a=audio(); if(a){a.pause();a.removeAttribute('src');a.load();}
    document.querySelectorAll('.meme-chaos-box').forEach(b=>b.classList.remove('sound-source'));
  }
  function applyChaos(on, userGesture=false) {
    document.body.classList.toggle('rgb-chaos', on);
    localStorage.setItem('novaOwnerRgbChaos', on ? '1' : '0');
    if (chaosTimer) clearInterval(chaosTimer); chaosTimer=null;
    if (on) {
      let hue=0; chaosTimer=setInterval(()=>{hue=(hue+24)%360;document.documentElement.style.setProperty('--chaos-hue',hue);},70);
      startMemes();
    } else { document.documentElement.style.removeProperty('--chaos-hue'); stopMemes(); }
    const b=findRgbButton(); if(b)b.textContent=on?'🌈 RGB CHAOS: ON':'🌈 RGB CHAOS: OFF';
  }
  window.addEventListener('DOMContentLoaded',()=>{
    const a=audio(); if(a)a.addEventListener('ended',chooseNextAudio);
    const b=findRgbButton(); if(!b)return;
    const clone=b.cloneNode(true); b.parentNode.replaceChild(clone,b);
    clone.addEventListener('click',()=>applyChaos(!document.body.classList.contains('rgb-chaos'),true));
    applyChaos(localStorage.getItem('novaOwnerRgbChaos')==='1');
  });
})();

// 0.8.4.0: restore/minimize/resize for all Nova windows, including the browser.
document.querySelectorAll('.window').forEach(w=>{
 w.style.resize='both';w.style.overflow='hidden';w.style.minWidth='340px';w.style.minHeight='220px';
 const max=w.querySelector('[data-max]');if(max)max.addEventListener('click',()=>{w.style.resize=w.dataset.max?'none':'both';},true);
});
// PARTY OVERKILL visual layer (0.8.4.0)
(function(){
  if(document.getElementById('partyOverkillFx')) return;
  const fx=document.createElement('div'); fx.id='partyOverkillFx';
  fx.innerHTML='<div id="partyHaze"></div><div class="partySpot s1"></div><div class="partySpot s2"></div><div class="partySpot s3"></div><div class="partySpot s4"></div><div id="partyDiscoBall"></div><div id="partyBassWave"></div><div id="partyDropGlow"></div><div id="partyConfetti"></div>';
  document.body.append(fx);
  const c=fx.querySelector('#partyConfetti');
  for(let i=0;i<46;i++){const b=document.createElement('i');b.className='confettiBit';b.style.left=(Math.random()*100)+'%';b.style.setProperty('--c',String(Math.floor(Math.random()*360)));b.style.setProperty('--d',(4+Math.random()*5)+'s');b.style.setProperty('--delay',(-Math.random()*8)+'s');b.style.setProperty('--r',(Math.random()*180)+'deg');b.style.setProperty('--drift',(-90+Math.random()*180)+'px');c.append(b)}
})();

// Party mode is independent of Owner RGB Chaos. Effects are cosmetic and stopped on exit.
(()=>{
 const videos=Array.from({length:10},(_,i)=>'./assets/party/party'+(i+1)+'.mp4');
 let active=false,movement=null,hueTimer=null,audioIndex=-1,boxes=[],audioCtx=null,analyser=null,sourceNode=null,audioRAF=null;
 const layer=document.getElementById('partyVideoLayer'), laser=document.getElementById('partyLaserLayer'),sound=document.getElementById('partyAudio');
 let dropPower=0,dropCooldown=0; let concertPulse=document.getElementById('concertPulseLayer'); if(!concertPulse){concertPulse=document.createElement('div');concertPulse.id='concertPulseLayer';document.body.append(concertPulse)} let lastBass=0,hit=0;
 const nextIndex=()=>{let n;do{n=Math.floor(Math.random()*videos.length)}while(videos.length>1&&n===audioIndex);return n};
 function nextSound(){if(!active)return;audioIndex=nextIndex();sound.src=videos[audioIndex];sound.volume=.62;sound.currentTime=0;sound.play().catch(()=>{});boxes.forEach((b,i)=>b.classList.toggle('party-sounding',i===audioIndex));}
 function initAudioReactive(){try{if(!audioCtx){audioCtx=new (window.AudioContext||window.webkitAudioContext)();analyser=audioCtx.createAnalyser();analyser.fftSize=256;analyser.smoothingTimeConstant=.72;sourceNode=audioCtx.createMediaElementSource(sound);sourceNode.connect(analyser);analyser.connect(audioCtx.destination)}audioCtx.resume?.();const data=new Uint8Array(analyser.frequencyBinCount);const tick=()=>{if(!active)return;analyser.getByteFrequencyData(data);const avg=(a,b)=>{let n=0;for(let i=a;i<b;i++)n+=data[i]||0;return n/Math.max(1,b-a)/255};const bass=Math.min(1,avg(1,12)*1.75),mid=Math.min(1,avg(12,42)*1.45),treble=Math.min(1,avg(42,100)*1.55);const kick=Math.max(0,bass-lastBass);lastBass=lastBass*.55+bass*.45;if(kick>.055&&bass>.28)hit=Math.min(1,.48+kick*3.8+bass*.24);else hit*=.82; if(dropCooldown>0)dropCooldown--; if((kick>.09&&bass>.48&&mid>.18)&&dropCooldown<=0){dropPower=1;dropCooldown=22;}else dropPower*=.88; document.body.style.setProperty('--drop-power',dropPower.toFixed(3));document.body.style.setProperty('--concert-hit',hit.toFixed(3));let hue=(330+bass*35+mid*125+treble*210)%360;document.body.style.setProperty('--bass',bass.toFixed(3));document.body.style.setProperty('--mid',mid.toFixed(3));document.body.style.setProperty('--treble',treble.toFixed(3));document.body.style.setProperty('--music-hue',hue.toFixed(1));audioRAF=requestAnimationFrame(tick)};cancelAnimationFrame(audioRAF);tick()}catch(e){console.warn('Audio visualizer unavailable',e)}}
 sound.addEventListener('ended',nextSound);
 function shuffle(){if(!active)return;boxes.forEach((b,i)=>{const width=Math.min(240,Math.max(130,innerWidth*.17));const height=width*.59;const usableW=Math.max(0,innerWidth-width-24),usableH=Math.max(0,innerHeight-height-115);b.style.left=Math.round(Math.random()*usableW)+'px';b.style.top=Math.round(30+Math.random()*usableH)+'px';b.style.width=width+'px';});}
 function start(){if(active)return;active=true;document.body.classList.add('party-mode');hueTimer=setInterval(()=>document.body.style.setProperty('--party-hue',String((Date.now()/12)%360)),80);layer.classList.remove('hidden');laser.classList.remove('hidden');layer.replaceChildren();boxes=videos.map((src,i)=>{const box=document.createElement('div');box.className='party-video';const v=document.createElement('video');v.src=src;v.muted=true;v.loop=true;v.autoplay=true;v.playsInline=true;v.preload='metadata';box.append(v);layer.append(box);v.play().catch(()=>{});return box});shuffle();movement=setInterval(shuffle,4200);initAudioReactive();nextSound();}
 function stop(){active=false;cancelAnimationFrame(audioRAF);clearInterval(movement);clearInterval(hueTimer);document.body.style.removeProperty('--party-hue');['--bass','--mid','--treble','--music-hue','--concert-hit','--drop-power'].forEach(x=>document.body.style.removeProperty(x));lastBass=0;hit=0;dropPower=0;dropCooldown=0;document.body.classList.remove('party-mode');layer.classList.add('hidden');laser.classList.add('hidden');sound.pause();sound.removeAttribute('src');sound.load();boxes.forEach(b=>{b.querySelector('video')?.pause()});layer.replaceChildren();boxes=[];}
 document.getElementById('ownerParty')?.addEventListener('click',()=>{if(!NOVA_OWNER_BUILD)return;active?stop():start();document.querySelector('#ownerParty span').textContent=active?'ON':'OFF';ownerLog('Party Mode '+(active?'AN':'AUS'));});
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&active){sound.pause();boxes.forEach(b=>b.querySelector('video')?.pause())}else if(active){sound.play().catch(()=>{});boxes.forEach(b=>b.querySelector('video')?.play().catch(()=>{}))}});
})();
// Nova Shortcuts: locally stored explicit actions; no hidden Windows commands.
const SHORTCUT_KEY='novaShortcuts0644';
try{if(!localStorage.getItem(SHORTCUT_KEY)&&localStorage.getItem('novaShortcuts0642'))localStorage.setItem(SHORTCUT_KEY,localStorage.getItem('novaShortcuts0642'));}catch{}let shortcutDraft=[];
function getShortcuts(){try{return JSON.parse(localStorage.getItem(SHORTCUT_KEY))||[]}catch{return []}}
function renderShortcutDraft(){const d=document.getElementById('shortcutSteps');if(d)d.textContent=shortcutDraft.map((a,i)=>(i+1)+'. '+a.type+(a.value?' — '+a.value:'')).join(' | ')}
function renderShortcuts(){const el=document.getElementById('shortcutList');if(!el)return;el.replaceChildren();getShortcuts().forEach(sc=>{const r=document.createElement('div');r.className='shortcutRow';const title=document.createElement('b');title.textContent=sc.name+' ('+sc.actions.length+' Aktionen)';const run=document.createElement('button');run.textContent='▶ Starten';run.onclick=()=>runShortcutByName(sc.name.toLowerCase());const del=document.createElement('button');del.textContent='Entfernen';del.onclick=()=>{localStorage.setItem(SHORTCUT_KEY,JSON.stringify(getShortcuts().filter(s=>s.name!==sc.name)));renderShortcuts()};r.append(title,run,del);el.append(r)})}
document.getElementById('shortcutAddAction')?.addEventListener('click',()=>{const type=document.getElementById('shortcutAction').value,value=document.getElementById('shortcutValue').value.trim();if(['url','game'].includes(type)&&!value)return toast('Bitte URL oder Spielnamen eingeben.');if(type==='url'&&!/^https:\/\//i.test(value))return toast('Nur https://-Webseiten sind erlaubt.');shortcutDraft.push({type,value});renderShortcutDraft();});
document.getElementById('shortcutSave')?.addEventListener('click',()=>{const name=document.getElementById('shortcutName').value.trim().toLowerCase();if(!/^[a-z0-9äöüß _-]{2,30}$/i.test(name)||!shortcutDraft.length)return toast('Name und mindestens eine Aktion erforderlich.');const all=getShortcuts().filter(s=>s.name!==name);all.push({name,actions:[...shortcutDraft]});localStorage.setItem(SHORTCUT_KEY,JSON.stringify(all));localStorage.setItem('novaShortcutTerminal',document.getElementById('shortcutAuto').checked?'1':'0');shortcutDraft=[];renderShortcutDraft();renderShortcuts();toast('Shortcut '+name+' gespeichert.');});
document.getElementById('shortcutClear')?.addEventListener('click',()=>{shortcutDraft=[];renderShortcutDraft()});
async function runShortcutByName(name){const sc=getShortcuts().find(s=>s.name===name);if(!sc)return false;for(const a of sc.actions){if(['browser','gaming','files'].includes(a.type))openApp(a.type);else if(a.type==='url'||a.type==='discord'){const u=a.type==='discord'?'https://discord.com/app':a.value;window.nova?.openUrl?.(u)||window.open(u,'_blank')}else if(a.type==='game'){const g=getGameLibrary().find(x=>x.name.toLowerCase()===a.value.toLowerCase());if(g){const result=await window.nova?.launchGame?.(g.path);if(!result?.ok)toast('Spielstart fehlgeschlagen.')}else toast('Spiel nicht im Gaming Hub gefunden: '+a.value)}}document.getElementById('terminal').classList.add('hidden');return true}
const oldShowDesktop=showDesktop;showDesktop=function(){oldShowDesktop();if(localStorage.getItem('novaShortcutTerminal')==='1')openApp('terminal')};

// 0.8.4.0 — clipboard shortcuts/context menu + real Nova app close lifecycle.
(()=>{
  const editable=el=>!!el?.closest?.('input,textarea,[contenteditable="true"]');
  const menu=document.createElement('div'); menu.id='novaContextMenu'; menu.className='hidden';
  for(const [label,cmd] of [['Ausschneiden','cut'],['Kopieren','copy'],['Einfügen','paste'],['Alles auswählen','selectAll']]){
    const b=document.createElement('button'); b.textContent=label; b.onclick=()=>{document.execCommand(cmd);menu.classList.add('hidden')}; menu.append(b);
  }
  document.body.append(menu);
  document.addEventListener('contextmenu',e=>{if(!editable(e.target))return;e.preventDefault();menu.style.left=Math.min(e.clientX,innerWidth-170)+'px';menu.style.top=Math.min(e.clientY,innerHeight-170)+'px';menu.classList.remove('hidden')});
  document.addEventListener('mousedown',e=>{if(!menu.contains(e.target))menu.classList.add('hidden')});
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&['c','v','x','a'].includes(e.key.toLowerCase())&&editable(e.target))e.stopPropagation()},true);

  function cleanupNovaApp(w){
    if(!w)return;
    w.querySelectorAll('audio,video').forEach(m=>{try{m.pause();m.currentTime=0}catch{}});
    if(w.id==='browser'){
      try{web.stop?.();web.src='about:blank';url.value='https://www.google.com'}catch{}
    }
  }
  document.querySelectorAll('.window').forEach(w=>{
    const close=w.querySelector('[data-close]'); if(!close)return;
    close.addEventListener('click',()=>cleanupNovaApp(w),true);
  });
  const originalOpenApp=openApp;
  openApp=function(id){originalOpenApp(id);if(id==='browser'&&(!web.src||web.src==='about:blank'))web.src='https://www.google.com'};
})();


// Nova 0.7 System Monitor + desktop polish
const nova07Start=Date.now(), monFpsHistory=Array(48).fill(0), monMemHistory=Array(48).fill(0);let monFrames=0,monLast=performance.now();
(function monFrame(){monFrames++;requestAnimationFrame(monFrame)})();
function drawSpark(id,data){const c=document.getElementById(id);if(!c)return;const x=c.getContext('2d'),w=c.width,h=c.height,max=Math.max(1,...data);x.clearRect(0,0,w,h);const grad=x.createLinearGradient(0,0,0,h);grad.addColorStop(0,getComputedStyle(document.documentElement).getPropertyValue('--cyan').trim()+'55');grad.addColorStop(1,'transparent');x.beginPath();data.forEach((v,i)=>{const px=i/(data.length-1)*w,py=h-8-(v/max)*(h-20);i?x.lineTo(px,py):x.moveTo(px,py)});x.lineTo(w,h);x.lineTo(0,h);x.closePath();x.fillStyle=grad;x.fill();x.beginPath();data.forEach((v,i)=>{const px=i/(data.length-1)*w,py=h-8-(v/max)*(h-20);i?x.lineTo(px,py):x.moveTo(px,py)});x.strokeStyle=getComputedStyle(document.documentElement).getPropertyValue('--cyan').trim();x.lineWidth=2;x.stroke()}
function monitorTick(){const now=performance.now(),fps=Math.min(240,Math.round(monFrames*1000/Math.max(1,now-monLast)));monFrames=0;monLast=now;const mem=performance.memory?Math.round(performance.memory.usedJSHeapSize/1048576):0;monFpsHistory.push(fps);monFpsHistory.shift();monMemHistory.push(mem);monMemHistory.shift();const sec=Math.floor((Date.now()-nova07Start)/1000),up=[Math.floor(sec/3600),Math.floor(sec%3600/60),sec%60].map(n=>String(n).padStart(2,'0')).join(':');document.getElementById('monFps')&&(document.getElementById('monFps').textContent=fps);document.getElementById('monMem')&&(document.getElementById('monMem').textContent=mem?mem+' MB':'n/a');document.getElementById('monCpu')&&(document.getElementById('monCpu').textContent=navigator.hardwareConcurrency||'--');document.getElementById('monUp')&&(document.getElementById('monUp').textContent=up);document.getElementById('networkState')&&(document.getElementById('networkState').textContent=navigator.onLine?'ONLINE':'OFFLINE');document.getElementById('healthValue')&&(document.getElementById('healthValue').textContent=navigator.onLine?'100':'92');drawSpark('fpsChart',monFpsHistory);drawSpark('memChart',monMemHistory)}
setInterval(()=>{if(!document.getElementById('monitor')?.classList.contains('hidden'))monitorTick()},1000);
window.addEventListener('online',()=>novaActivity('Network connection restored.'));window.addEventListener('offline',()=>novaActivity('Network connection lost.'));
function novaActivity(msg){const f=document.getElementById('activityFeed');if(!f)return;const p=document.createElement('p'),t=document.createElement('time');t.textContent=new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'});p.append(t,document.createTextNode(msg));f.prepend(p);while(f.children.length>6)f.lastElementChild.remove()}
document.querySelectorAll('[data-open]').forEach(b=>b.addEventListener('click',()=>{if(b.closest('#icons'))return;novaActivity('Opened '+b.dataset.open+'.')}));
function searchableApps(){return Object.values(NOVA_APPS).filter(a=>!a.store||isStoreInstalled(a.id));}
function findApps(q){const term=(q||'').trim().toLowerCase();const apps=searchableApps();if(!term)return apps;return apps.filter(a=>[a.name,a.id,...a.keywords].join(' ').toLowerCase().includes(term));}
function renderTaskSearch(q=''){const box=document.getElementById('taskSearchResults'); if(!box) return; const items=findApps(q).slice(0,6); box.innerHTML=items.map(a=>`<button class="taskSearchResult" data-open="${a.id}"><span class="taskappIcon">${a.icon}</span><span><b>${a.name}</b><small>${a.keywords[0]||''}</small></span></button>`).join('')||'<div class="taskSearchEmpty">Keine Ergebnisse</div>'; box.querySelectorAll('[data-open]').forEach(b=>b.onclick=()=>{openApp(b.dataset.open); document.getElementById('taskSearchPanel')?.classList.add('hidden'); document.getElementById('taskSearch').value='';});}
const appSearch07=document.getElementById('appSearch');
appSearch07?.addEventListener('input',()=>{const q=appSearch07.value.trim().toLowerCase();document.querySelectorAll('#start .startGrid button').forEach(b=>b.style.display=!q||b.textContent.toLowerCase().includes(q)?'':'none')});
appSearch07?.addEventListener('keydown',e=>{if(e.key==='Enter'){const b=[...document.querySelectorAll('#start .startGrid button')].find(x=>x.style.display!=='none');b?.click()}});
const taskSearch=document.getElementById('taskSearch'), taskSearchPanel=document.getElementById('taskSearchPanel');
renderTaskSearch('');
taskSearch?.addEventListener('focus',()=>{taskSearchPanel?.classList.remove('hidden');renderTaskSearch(taskSearch.value)});
taskSearch?.addEventListener('input',()=>{taskSearchPanel?.classList.remove('hidden');renderTaskSearch(taskSearch.value)});
taskSearch?.addEventListener('keydown',e=>{if(e.key==='Enter'){const first=findApps(taskSearch.value)[0]; if(first){openApp(first.id); taskSearch.value=''; taskSearchPanel?.classList.add('hidden');}} if(e.key==='Escape'){taskSearchPanel?.classList.add('hidden')}});

(function(){const nav=[...document.querySelectorAll('#settingsNav [data-settings-page]')],pages=[...document.querySelectorAll('#settings .settingsPage')];nav.forEach(btn=>btn.addEventListener('click',()=>{nav.forEach(x=>x.classList.remove('active'));btn.classList.add('active');pages.forEach(p=>p.classList.toggle('active',p.dataset.page===btn.dataset.settingsPage));}));function sync(){const a=document.querySelector('#accountName');if(a)a.textContent=(profile&&profile.name)||'Nova User';}document.querySelector('#accountLock')?.addEventListener('click',showLock);document.querySelector('#densityToggle')?.addEventListener('click',e=>{document.body.classList.toggle('compact-desktop');e.currentTarget.textContent=document.body.classList.contains('compact-desktop')?'Standard':'Kompakt';});document.querySelector('#glassToggle')?.addEventListener('click',()=>document.body.classList.toggle('no-glass'));const net=()=>{const on=navigator.onLine,st=document.querySelector('#settingsNetworkState'),tx=document.querySelector('#settingsNetworkText'),p=document.querySelector('#networkPill');if(st)st.textContent=on?'Verbunden':'Offline';if(tx)tx.textContent=on?'Nova kann das Netzwerk erreichen.':'Keine aktive Verbindung erkannt.';if(p){p.textContent=on?'ONLINE':'OFFLINE';p.classList.toggle('offline',!on);}};window.addEventListener('online',net);window.addEventListener('offline',net);net();sync();})();


// Nova Store 0.8.4 — reliable navigation, details and install progress
const STORE_CATALOG={
 notes:{id:'notes',name:'Nova Notes',icon:'✎',category:'productivity',categoryLabel:'Produktivität',version:'1.1',size:'0,4 MB',description:'Schnelle Notizen mit automatischer lokaler Speicherung.',featured:true},
 clockapp:{id:'clockapp',name:'Nova Clock',icon:'◷',category:'utilities',categoryLabel:'Tools',version:'1.0',size:'0,2 MB',description:'Eine ruhige Uhr mit Datum und lokaler Systemzeit.'},
 tasks:{id:'tasks',name:'Nova Tasks',icon:'✓',category:'productivity',categoryLabel:'Produktivität',version:'1.1',size:'0,5 MB',description:'Einfache Aufgabenliste, lokal in Nova gespeichert.'},
 calculator:{id:'calculator',name:'Nova Calculator',icon:'＋',category:'utilities',categoryLabel:'Tools',version:'1.0',size:'0,3 MB',description:'Schneller Rechner im Nova-Stil – komplett lokal.'},
 focus:{id:'focus',name:'Nova Focus',icon:'◉',category:'productivity',categoryLabel:'Produktivität',version:'1.0',size:'0,4 MB',description:'Minimaler Fokus-Timer mit 15-, 25- und 45-Minuten-Presets.'}
};
let storeFilter='all';
const storeInstalling=new Set();

function getStoreInstalled(){
  try{
    const value=JSON.parse(localStorage.getItem('novaStoreInstalled')||'[]');
    return (Array.isArray(value)?value:[]).filter(id=>NOVA_APPS[id]?.store && STORE_CATALOG[id]);
  }catch{return[]}
}
function saveStoreInstalled(ids){
  localStorage.setItem('novaStoreInstalled',JSON.stringify([...new Set(ids)].filter(id=>STORE_CATALOG[id])));
  renderStore();
  renderInstalledStartApps();
  updateInstalledCount();
  renderTaskSearch(document.getElementById('taskSearch')?.value||'');
}
function isStoreInstalled(id){return getStoreInstalled().includes(id)}
const delay=ms=>new Promise(r=>setTimeout(r,ms));

function setStoreInstallProgress(id,p){
  document.querySelectorAll(`[data-store-progress="${id}"]`).forEach(el=>{
    el.classList.remove('hidden');
    const bar=el.querySelector('span'); if(bar)bar.style.width=Math.max(0,Math.min(100,p))+'%';
  });
}
async function installStoreApp(id,button){
  const app=STORE_CATALOG[id];
  if(!app||storeInstalling.has(id))return;
  if(isStoreInstalled(id)){openApp(id);return;}
  storeInstalling.add(id);
  if(button){button.disabled=true;button.textContent='0%';}
  for(const pct of [8,20,35,52,68,82,94,100]){
    await delay(95);
    if(button)button.textContent=pct+'%';
    setStoreInstallProgress(id,pct);
  }
  storeInstalling.delete(id);
  saveStoreInstalled([...getStoreInstalled(),id]);
  toast(app.name+' wurde installiert.');
  if(!document.getElementById('storeDetail')?.classList.contains('hidden'))openStoreDetails(id);
}
function uninstallStoreApp(id){
  const app=STORE_CATALOG[id];
  if(!app||!isStoreInstalled(id))return;
  if(!confirm(app.name+' deinstallieren?'))return;
  document.getElementById(id)?.classList.add('hidden');
  removeTask(id);
  saveStoreInstalled(getStoreInstalled().filter(x=>x!==id));
  toast(app.name+' wurde deinstalliert.');
  if(!document.getElementById('storeDetail')?.classList.contains('hidden'))openStoreDetails(id);
}
function storeCard(app){
  const installed=isStoreInstalled(app.id);
  return `<article class="storeCard" data-store-details="${app.id}" tabindex="0" role="button" aria-label="${app.name} Details öffnen">
    <div class="storeCardTop"><div class="storeAppIcon">${app.icon}</div><span class="storeCategory">${app.categoryLabel}</span></div>
    <h3>${app.name}</h3><p>${app.description}</p>
    <div class="storeMeta"><span>v${app.version}</span><span>${app.size}</span><span>Nova Verified</span></div>
    <div class="storeInstallProgress hidden" data-store-progress="${app.id}"><span></span></div>
    <div class="storeActions">${installed
      ?`<button class="primaryStore" data-store-open="${app.id}">Öffnen</button><button data-store-remove="${app.id}">Deinstallieren</button>`
      :`<button class="primaryStore" data-store-install="${app.id}">Installieren</button>`}
    </div>
  </article>`;
}
function renderStoreNavCounts(){
  const all=Object.values(STORE_CATALOG);
  const counts={
    all:all.length,
    productivity:all.filter(a=>a.category==='productivity').length,
    utilities:all.filter(a=>a.category==='utilities').length,
    installed:getStoreInstalled().length
  };
  Object.entries(counts).forEach(([key,val])=>{
    const el=document.querySelector(`[data-store-nav-count="${key}"]`);
    if(el)el.textContent=String(val);
  });
}
function selectStoreFilter(filter){
  storeFilter=['all','productivity','utilities','installed'].includes(filter)?filter:'all';
  document.querySelectorAll('[data-store-filter]').forEach(x=>x.classList.toggle('active',x.dataset.storeFilter===storeFilter));
  const feature=document.querySelector('.storeFeature');
  if(feature)feature.classList.toggle('hidden',storeFilter!=='all');
  closeStoreDetails();
  renderStore();
}
function renderStore(){
  const grid=document.getElementById('storeGrid');
  if(!grid)return;
  renderStoreNavCounts();
  const q=(document.getElementById('storeSearch')?.value||'').trim().toLowerCase();
  let apps=Object.values(STORE_CATALOG);
  if(storeFilter==='installed')apps=apps.filter(a=>isStoreInstalled(a.id));
  else if(storeFilter!=='all')apps=apps.filter(a=>a.category===storeFilter);
  if(q)apps=apps.filter(a=>(a.name+' '+a.description+' '+a.categoryLabel).toLowerCase().includes(q));
  const emptyText=storeFilter==='installed'
    ?'Noch keine Store-Apps installiert. Unter „Entdecken“ kannst du Apps hinzufügen.'
    :'Keine Apps gefunden.';
  grid.innerHTML=apps.map(storeCard).join('')||`<div class="storeEmpty">${emptyText}</div>`;
  const count=document.getElementById('storeCount');
  if(count)count.textContent=apps.length+' '+(apps.length===1?'App':'Apps');
  const titles={all:'Apps entdecken',productivity:'Produktivität',utilities:'Tools',installed:'Meine Apps'};
  const sectionTitle=document.getElementById('storeSectionTitle');
  if(sectionTitle)sectionTitle.textContent=titles[storeFilter]||'Apps';

  grid.querySelectorAll('[data-store-details]').forEach(card=>{
    card.addEventListener('click',e=>{if(e.target.closest('button'))return;openStoreDetails(card.dataset.storeDetails)});
    card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openStoreDetails(card.dataset.storeDetails)}});
  });
  grid.querySelectorAll('[data-store-install]').forEach(b=>b.onclick=e=>{e.stopPropagation();installStoreApp(b.dataset.storeInstall,b)});
  grid.querySelectorAll('[data-store-open]').forEach(b=>b.onclick=e=>{e.stopPropagation();openApp(b.dataset.storeOpen)});
  grid.querySelectorAll('[data-store-remove]').forEach(b=>b.onclick=e=>{e.stopPropagation();uninstallStoreApp(b.dataset.storeRemove)});

  const feat=document.querySelector('[data-store-action="notes"]');
  if(feat){
    feat.textContent=isStoreInstalled('notes')?'Öffnen':'Installieren';
    feat.onclick=()=>isStoreInstalled('notes')?openApp('notes'):installStoreApp('notes',feat);
  }
}
function openStoreDetails(id){
  const app=STORE_CATALOG[id],panel=document.getElementById('storeDetail');
  if(!app||!panel)return;
  document.getElementById('storeDetailIcon').textContent=app.icon;
  document.getElementById('storeDetailCategory').textContent=app.categoryLabel+' · NOVA VERIFIED';
  document.getElementById('storeDetailName').textContent=app.name;
  document.getElementById('storeDetailDescription').textContent=app.description;
  document.getElementById('storeDetailMeta').innerHTML=`<span>Version ${app.version}</span><span>${app.size}</span><span>Lokal</span>`;
  const actions=document.getElementById('storeDetailActions');
  const installed=isStoreInstalled(id);
  actions.innerHTML=installed
    ?`<button class="primaryStore" data-detail-open="${id}">Öffnen</button><button data-detail-remove="${id}">Deinstallieren</button>`
    :`<button class="primaryStore" data-detail-install="${id}">Installieren</button>`;
  actions.querySelector('[data-detail-open]')?.addEventListener('click',()=>openApp(id));
  actions.querySelector('[data-detail-remove]')?.addEventListener('click',()=>uninstallStoreApp(id));
  const install=actions.querySelector('[data-detail-install]');
  install?.addEventListener('click',()=>installStoreApp(id,install));
  panel.classList.remove('hidden');
}
function closeStoreDetails(){document.getElementById('storeDetail')?.classList.add('hidden')}
function renderInstalledStartApps(){
  const sec=document.getElementById('storeAppsStartSection'),grid=document.getElementById('storeAppsStartGrid');
  if(!sec||!grid)return;
  const ids=getStoreInstalled();
  sec.classList.toggle('hidden',ids.length===0);
  grid.innerHTML=ids.map(id=>{const a=NOVA_APPS[id];return `<button data-open="${id}"><span class="startAppIcon">${a.icon}</span><span>${a.name.replace('Nova ','')}</span></button>`}).join('');
  grid.querySelectorAll('[data-open]').forEach(b=>b.onclick=()=>openApp(b.dataset.open));
}
function updateInstalledCount(){
  const el=document.getElementById('installedAppCount');
  if(el)el.textContent=(7+getStoreInstalled().length)+' APPS';
}

// Capture-phase navigation keeps Store categories clickable even when window drag/focus handlers fire.
document.addEventListener('click',e=>{
  const nav=e.target.closest('#store [data-store-filter]');
  if(!nav)return;
  e.preventDefault();
  e.stopPropagation();
  selectStoreFilter(nav.dataset.storeFilter);
},true);

document.getElementById('storeSearch')?.addEventListener('input',()=>renderStore());
document.getElementById('storeDetailClose')?.addEventListener('click',closeStoreDetails);
document.getElementById('openStoreSettings')?.addEventListener('click',()=>openApp('store'));
renderStore();
renderInstalledStartApps();
updateInstalledCount();

// Nova Notes
const notesText=document.getElementById('notesText'),notesSaved=document.getElementById('notesSaved');if(notesText){notesText.value=localStorage.getItem('novaNotesText')||'';let notesTimer;notesText.addEventListener('input',()=>{if(notesSaved)notesSaved.textContent='Speichert…';clearTimeout(notesTimer);notesTimer=setTimeout(()=>{localStorage.setItem('novaNotesText',notesText.value);if(notesSaved)notesSaved.textContent='Lokal gespeichert';},300)});}

// Nova Clock
function tickStoreClock(){const n=new Date(),t=document.getElementById('storeClockTime'),d=document.getElementById('storeClockDate');if(t)t.textContent=n.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit',second:'2-digit'});if(d)d.textContent=n.toLocaleDateString('de-DE',{weekday:'long',day:'numeric',month:'long',year:'numeric'});}tickStoreClock();setInterval(tickStoreClock,1000);

// Nova Tasks
function getTasks(){try{return JSON.parse(localStorage.getItem('novaTasks')||'[]')}catch{return[]}}
function saveTasks(v){localStorage.setItem('novaTasks',JSON.stringify(v));renderTasks();}
function renderTasks(){const box=document.getElementById('taskItems');if(!box)return;const tasks=getTasks();const open=tasks.filter(t=>!t.done).length;const c=document.getElementById('tasksCount');if(c)c.textContent=open+' OFFEN';box.innerHTML=tasks.map((t,i)=>`<div class="taskItem ${t.done?'done':''}"><button class="taskCheck" data-task-check="${i}">${t.done?'✓':''}</button><span>${escapeHtml(t.text)}</span><button class="taskDelete" data-task-delete="${i}">×</button></div>`).join('')||'<div class="tasksEmpty">Noch keine Aufgaben. Füge oben deine erste hinzu.</div>';box.querySelectorAll('[data-task-check]').forEach(b=>b.onclick=()=>{const a=getTasks(),i=Number(b.dataset.taskCheck);a[i].done=!a[i].done;saveTasks(a)});box.querySelectorAll('[data-task-delete]').forEach(b=>b.onclick=()=>{const a=getTasks();a.splice(Number(b.dataset.taskDelete),1);saveTasks(a)});}
function addTaskItem(){const input=document.getElementById('taskAddInput');const text=input?.value.trim();if(!text)return;const a=getTasks();a.unshift({text,done:false});saveTasks(a);input.value='';}
document.getElementById('taskAddButton')?.addEventListener('click',addTaskItem);document.getElementById('taskAddInput')?.addEventListener('keydown',e=>{if(e.key==='Enter')addTaskItem()});renderTasks();

// Nova Calculator 0.8.3
let calcCurrent='0', calcStored=null, calcOperator=null, calcWaiting=false;
function calcRender(){const v=document.getElementById('calcValue'),h=document.getElementById('calcHistory');if(v)v.textContent=calcCurrent.replace('.',',');if(h)h.textContent=calcOperator&&calcStored!==null?`${String(calcStored).replace('.',',')} ${calcOperator==='*'?'×':calcOperator==='/'?'÷':calcOperator}`:'Bereit';}
function calcApply(){if(calcStored===null||!calcOperator)return Number(calcCurrent);const a=Number(calcStored),b=Number(calcCurrent);if(calcOperator==='+')return a+b;if(calcOperator==='-')return a-b;if(calcOperator==='*')return a*b;if(calcOperator==='/')return b===0?NaN:a/b;return b;}
document.getElementById('calcKeys')?.addEventListener('click',e=>{const b=e.target.closest('[data-calc]');if(!b)return;const k=b.dataset.calc;if(/^\d$/.test(k)){calcCurrent=(calcWaiting||calcCurrent==='0')?k:calcCurrent+k;calcWaiting=false;}else if(k==='.'){if(calcWaiting){calcCurrent='0.';calcWaiting=false}else if(!calcCurrent.includes('.'))calcCurrent+='.';}else if(k==='clear'){calcCurrent='0';calcStored=null;calcOperator=null;calcWaiting=false;}else if(k==='sign'){calcCurrent=String(Number(calcCurrent)*-1);}else if(k==='percent'){calcCurrent=String(Number(calcCurrent)/100);}else if(['+','-','*','/'].includes(k)){if(calcOperator&&!calcWaiting){const r=calcApply();calcCurrent=Number.isFinite(r)?String(Math.round(r*1e10)/1e10):'Fehler';}calcStored=calcCurrent==='Fehler'?0:Number(calcCurrent);calcOperator=k;calcWaiting=true;}else if(k==='='){const r=calcApply();calcCurrent=Number.isFinite(r)?String(Math.round(r*1e10)/1e10):'Fehler';calcStored=null;calcOperator=null;calcWaiting=true;}calcRender();});calcRender();

// Nova Focus 0.8.3
let focusDuration=25*60,focusRemaining=focusDuration,focusRunning=false,focusEnd=0,focusTimer=null;
function focusRender(){const t=document.getElementById('focusTime'),st=document.getElementById('focusState'),start=document.getElementById('focusStart');const m=Math.floor(focusRemaining/60),sec=focusRemaining%60;if(t)t.textContent=`${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;if(st)st.textContent=focusRunning?'LÄUFT':focusRemaining===0?'FERTIG':'BEREIT';if(start)start.textContent=focusRunning?'Pause':focusRemaining===0?'Neu starten':'Start';}
function focusStopTicker(){if(focusTimer){clearInterval(focusTimer);focusTimer=null;}}
function focusTick(){if(!focusRunning)return;focusRemaining=Math.max(0,Math.ceil((focusEnd-Date.now())/1000));if(focusRemaining<=0){focusRunning=false;focusStopTicker();toast('Nova Focus: Zeit ist um.');}focusRender();}
document.querySelectorAll('[data-focus-minutes]').forEach(b=>b.addEventListener('click',()=>{focusRunning=false;focusStopTicker();focusDuration=Number(b.dataset.focusMinutes)*60;focusRemaining=focusDuration;document.querySelectorAll('[data-focus-minutes]').forEach(x=>x.classList.toggle('active',x===b));focusRender();}));
document.getElementById('focusStart')?.addEventListener('click',()=>{if(focusRunning){focusRunning=false;focusRemaining=Math.max(0,Math.ceil((focusEnd-Date.now())/1000));focusStopTicker();}else{if(focusRemaining<=0)focusRemaining=focusDuration;focusRunning=true;focusEnd=Date.now()+focusRemaining*1000;focusStopTicker();focusTimer=setInterval(focusTick,250);}focusRender();});
document.getElementById('focusReset')?.addEventListener('click',()=>{focusRunning=false;focusStopTicker();focusRemaining=focusDuration;focusRender();});focusRender();

// Nova Update — STANDARD stable channel with automatic install + restart
(function(){
 const check=document.querySelector('#checkUpdates'), dl=document.querySelector('#downloadUpdate');
 const status=document.querySelector('#updateStatus'), pill=document.querySelector('#updatePill'), head=document.querySelector('#updateHeadline'), notes=document.querySelector('#updateNotes'), row=document.querySelector('#downloadUpdateRow'), av=document.querySelector('#availableVersion');
 const progress=document.querySelector('#updateProgress'), fill=document.querySelector('#updateProgressFill'), progressText=document.querySelector('#updateProgressText');
 const setProgress=(p,text)=>{if(progress)progress.classList.remove('hidden');if(fill)fill.style.width=Math.max(0,Math.min(100,p||0))+'%';if(progressText)progressText.textContent=text||'';};
 if(window.nova?.onUpdateProgress){window.nova.onUpdateProgress(data=>{setProgress(data?.percent||0,data?.text||'Update läuft…');status.textContent=data?.text||'Update läuft…';pill.textContent=data?.phase==='verify'?'PRÜFEN':'DOWNLOAD';});}
 if(!check||!window.nova?.checkForUpdates)return;
 check.addEventListener('click',async()=>{
   check.disabled=true; check.textContent='Suche…'; status.textContent='Nova verbindet sich mit dem STANDARD-Updatekanal…'; pill.textContent='CHECK'; row?.classList.add('hidden');progress?.classList.add('hidden');
   let x; try{x=await window.nova.checkForUpdates();}catch(err){x={ok:false,error:err?.message||String(err)}}
   check.disabled=false; check.textContent='Jetzt prüfen';
   if(!x.ok){pill.textContent='FEHLER';status.textContent='Update-Suche fehlgeschlagen: '+x.error;return;}
   if(x.available){pill.textContent='UPDATE';head.textContent='Nova '+x.version+' ist verfügbar';status.textContent='Eine neuere STANDARD-Version wurde gefunden.';notes.textContent=x.notes||'Neues Nova-Update verfügbar.';av.textContent='Nova '+x.version;row?.classList.remove('hidden');}
   else {pill.textContent='AKTUELL';head.textContent='Du bist auf dem neuesten Stand';status.textContent='Nova '+x.current+' ist aktuell.';notes.textContent='Keine neuere STANDARD-Version verfügbar.';}
 });
 dl?.addEventListener('click',async()=>{
   dl.disabled=true;dl.textContent='Wird installiert…';pill.textContent='DOWNLOAD';setProgress(0,'Download wird vorbereitet…');status.textContent='Update wird heruntergeladen, geprüft und anschließend installiert…';
   let x;try{x=await window.nova.downloadUpdate();}catch(err){x={ok:false,error:err?.message||String(err)}}
   if(x?.ok&&x?.installing){pill.textContent='NEUSTART';status.textContent='Update geprüft. Nova startet gleich in den Update-Modus…';setProgress(100,'SHA-256 geprüft · Nova wird neu gestartet…');return;}
   dl.disabled=false;dl.textContent='Herunterladen & installieren';
   if(x?.ok){pill.textContent='BEREIT';status.textContent='Update wurde vorbereitet.';}else{pill.textContent='FEHLER';status.textContent='Update fehlgeschlagen: '+(x?.error||'Unbekannter Fehler');}
 });
})();

// Nova 0.8 small OS interactions
document.querySelector('#storageClean')?.addEventListener('click',()=>toast('Speicherprüfung abgeschlossen – keine temporären Nova-Dateien müssen entfernt werden.'));
